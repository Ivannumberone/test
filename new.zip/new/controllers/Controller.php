<?
namespace controllers;
class Controller
{   	
	public static $contentView;
}