<?php 
  $dbDsn = '';
  $dbUser = '';
  $dbPassword  = '';
  const BASE_URL = 'http://localhost/new/';
  $allPages = array('main','add');
  
  