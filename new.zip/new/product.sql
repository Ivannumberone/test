﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 8.0.124.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 22.05.2019 13:06:54
-- Версия сервера: 5.6.37-82.2-log
-- Версия клиента: 4.1
--


SET NAMES 'utf8';

INSERT INTO tmp.product(id, name, price) VALUES
(1, 'iPhone 5S', 299),
(2, 'iPad mini', 299),
(3, 'MacBook Air', 999),
(4, 'iPhone 6', 499),
(7, 'Apple Watch Sport', 399),
(8, 'Apple Watch Gold Edition', 9999),
(9, 'iPad Pro', 899),
(10, 'MacBook Pro', 1299),
(13, 'iPod Touch', 249),
(20, 'iPhone SE', 399),
(21, '34234', 0),
(22, '657657', 0),
(23, '3432432', 0),
(24, '''', 0),
(25, '\\\\''\\', 0),
(26, '&lt;&gt;', 0),
(27, '&quot;', 0);